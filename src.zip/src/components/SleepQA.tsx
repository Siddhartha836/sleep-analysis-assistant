
import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { HelpCircle, Send, Brain } from "lucide-react";

interface Message {
  id: string;
  text: string;
  type: 'user' | 'assistant';
  timestamp: Date;
}

interface SleepQAProps {
  onQuestionAsked?: (question: string) => void;
}

// Expanded sleep knowledge base with more comprehensive answers
const sleepAnswers = [
  {
    keywords: ["improve", "better", "quality"],
    answer: "To improve sleep quality, establish a consistent sleep schedule, create a relaxing bedtime routine, make your bedroom dark and quiet, avoid screens before bed, limit caffeine and alcohol, and stay physically active during the day."
  },
  {
    keywords: ["insomnia", "can't sleep", "trouble sleeping", "difficult"],
    answer: "Insomnia can be addressed by practicing good sleep hygiene, cognitive behavioral therapy, relaxation techniques like deep breathing, and avoiding stimulants. If persistent, consider consulting a healthcare provider."
  },
  {
    keywords: ["hours", "how much", "how long", "need", "enough", "6", "six", "7", "seven", "8", "eight"],
    answer: "Adults typically need 7-9 hours of sleep per night. While some people can function with 6 hours, research suggests most adults need at least 7 hours for optimal health. Individual needs may vary based on genetics, activity level, health conditions, and age. Consistently getting less than 7 hours may lead to health issues over time."
  },
  {
    keywords: ["dreams", "dreaming", "nightmares", "remember"],
    answer: "Dreams occur primarily during REM sleep. To better remember dreams, try keeping a dream journal by your bed and write them down immediately upon waking. Reducing stress and maintaining regular sleep patterns can lead to more vivid dreams."
  },
  {
    keywords: ["melatonin", "supplements", "medication"],
    answer: "Melatonin is a natural hormone that helps regulate sleep. As a supplement, it may help with occasional insomnia or jet lag. Start with a low dose (0.5-1mg) and consult with a healthcare provider before regular use."
  },
  {
    keywords: ["nap", "napping", "afternoon", "day"],
    answer: "Short power naps (20-30 minutes) can boost alertness and performance without causing sleep inertia. Limit naps to early afternoon and keep them brief to avoid interfering with nighttime sleep."
  },
  {
    keywords: ["temperature", "hot", "cold", "room"],
    answer: "The ideal bedroom temperature for sleep is between 60-67°F (15-20°C). A room that's too hot or too cold can disrupt sleep. Your body temperature naturally drops during sleep, so a cooler room often promotes better sleep."
  },
  {
    keywords: ["caffeine", "coffee", "tea"],
    answer: "Caffeine can remain in your system for 6+ hours and interfere with falling asleep. Try to avoid caffeine after mid-afternoon, and consider gradually reducing overall consumption if sleep problems persist."
  },
  {
    keywords: ["exercise", "workout", "physical activity"],
    answer: "Regular exercise can improve sleep quality, but timing matters. Morning or afternoon exercise is ideal. Evening workouts may energize some people and make it harder to fall asleep, though this varies by individual."
  },
  {
    keywords: ["stress", "anxiety", "worry", "relax"],
    answer: "To manage sleep-disrupting stress, try relaxation techniques like deep breathing, progressive muscle relaxation, or meditation before bed. Writing down worries or to-dos for tomorrow can help clear your mind."
  },
  {
    keywords: ["food", "eat", "meal", "dinner", "before bed"],
    answer: "Avoid large meals 2-3 hours before bedtime. If you're hungry, opt for a light snack containing tryptophan, like a small amount of turkey, a banana, or a glass of milk, which may promote sleepiness."
  },
  {
    keywords: ["alcohol", "drinking", "wine", "beer"],
    answer: "While alcohol may help you fall asleep initially, it disrupts sleep cycles, particularly REM sleep, leading to less restful sleep. Try to avoid alcohol within 3 hours of bedtime for better sleep quality."
  },
  {
    keywords: ["snoring", "apnea", "breathing"],
    answer: "Snoring may indicate sleep apnea, a serious sleep disorder. Side sleeping, maintaining healthy weight, and avoiding alcohol before bed can help. If snoring is loud or you experience daytime fatigue, consult a doctor."
  },
  {
    keywords: ["rem", "deep", "cycle", "stages"],
    answer: "Sleep consists of multiple 90-minute cycles with both REM and non-REM stages. Deep sleep (stages 3-4) occurs more in the first half of the night and is vital for physical restoration. REM sleep increases later and is important for cognitive functions and memory consolidation."
  },
  {
    keywords: ["gadgets", "phone", "screen", "blue light"],
    answer: "The blue light from screens can suppress melatonin production. Try to avoid screens 1-2 hours before bed, or use night mode/blue light filters. Consider reading a physical book or practicing relaxation techniques instead."
  },
  {
    keywords: ["circadian", "rhythm", "body clock", "schedule"],
    answer: "Your circadian rhythm is your body's internal clock that regulates sleep-wake cycles. Maintain a consistent sleep schedule, get morning sunlight, and limit evening light exposure to keep your circadian rhythm healthy."
  },
  {
    keywords: ["only", "just", "6", "six", "hours"],
    answer: "While the recommended sleep for adults is 7-9 hours, some people may function adequately with 6 hours. This varies by individual and may be influenced by genetics. However, research suggests that consistently sleeping less than 7 hours is associated with various health risks including impaired immune function, increased inflammation, weight gain, and reduced cognitive performance. If you're feeling well-rested and functioning properly with 6 hours, you might be among those who need less sleep, but monitor your health and energy levels."
  },
  {
    keywords: ["wake", "waking", "up", "middle", "night"],
    answer: "Waking up in the middle of the night is common. Try to identify the cause: bathroom needs, noise, temperature, stress, or sleep disorders. Keep the room dark if you wake up, avoid checking the time, and try relaxation techniques to fall back asleep. If it's persistent, consider consulting a healthcare provider."
  },
  {
    keywords: ["pillow", "mattress", "bed", "comfortable"],
    answer: "Your sleep surface matters. A good mattress and pillow should support your body's natural alignment and pressure points. Most mattresses should be replaced every 7-10 years. Choose a pillow that supports your neck based on your sleep position: side sleepers need thicker pillows, while back sleepers need medium support."
  },
  {
    keywords: ["pregnant", "pregnancy"],
    answer: "During pregnancy, sleep challenges are common due to hormonal changes, physical discomfort, and increased urination. Sleep on your left side to improve circulation, use pregnancy pillows for support, maintain a cool bedroom, stay hydrated during the day but limit fluids before bed, and consider gentle exercises like prenatal yoga to improve sleep quality."
  }
];

// Advanced answer generation with fallback for questions without direct matches
const findAnswer = (question: string): string => {
  const questionLower = question.toLowerCase();
  
  // First, try exact keyword matching
  let bestMatch = null;
  let highestScore = 0;
  
  for (const item of sleepAnswers) {
    let score = 0;
    for (const keyword of item.keywords) {
      if (questionLower.includes(keyword.toLowerCase())) {
        score++;
      }
    }
    
    if (score > highestScore) {
      highestScore = score;
      bestMatch = item;
    }
  }
  
  // If we have a strong match (at least 2 keywords or more)
  if (bestMatch && highestScore >= 1) {
    return bestMatch.answer;
  }
  
  // For questions without strong keyword matches, provide a generalized response
  // based on the question context
  
  // Sleep duration related
  if (questionLower.includes("hour") || 
      /\d+\s*(hr|hour|hrs|hours)/.test(questionLower) ||
      questionLower.includes("long") || 
      questionLower.includes("enough")) {
    return "For most adults, 7-9 hours of sleep per night is recommended. Teenagers need 8-10 hours, school-age children 9-12 hours, and infants even more. Some adults can function with 6 hours due to genetic factors, but studies show chronic sleep deprivation (less than 7 hours regularly) is linked to health issues including cardiovascular problems, weakened immunity, and cognitive decline.";
  }
  
  // Sleep quality related
  if (questionLower.includes("quality") || 
      questionLower.includes("better") || 
      questionLower.includes("improve")) {
    return "Sleep quality is affected by many factors including environment (temperature, noise, light), habits (screen time, caffeine, exercise), and health conditions. To improve sleep quality: maintain a consistent sleep schedule, create a bedtime routine, optimize your bedroom environment, limit daytime naps, manage stress, and exercise regularly but not too close to bedtime.";
  }
  
  // Sleep position related
  if (questionLower.includes("position") || 
      questionLower.includes("side") || 
      questionLower.includes("back") || 
      questionLower.includes("stomach")) {
    return "The best sleep position depends on your health needs. Side sleeping, especially on the left, can reduce acid reflux and snoring, and is recommended during pregnancy. Back sleeping maintains spine alignment but may worsen sleep apnea. Stomach sleeping can strain the neck and back. Try using pillows strategically to support your preferred position.";
  }
  
  // General sleep health
  if (questionLower.includes("health") || 
      questionLower.includes("healthy") || 
      questionLower.includes("important")) {
    return "Quality sleep is essential for overall health. During sleep, your body repairs tissues, strengthens immunity, processes memories, and clears waste from the brain. Chronic sleep deprivation is linked to serious health issues including heart disease, diabetes, obesity, depression, and reduced cognitive function. Prioritizing sleep is as important as diet and exercise for wellbeing.";
  }
  
  // Food and diet related
  if (questionLower.includes("food") || 
      questionLower.includes("eat") || 
      questionLower.includes("diet") || 
      questionLower.includes("drink")) {
    return "Some foods can promote sleep, including those containing tryptophan (turkey, milk, nuts), magnesium (leafy greens, nuts), and melatonin (cherries, grapes). Avoid large meals 2-3 hours before bed. Limit caffeine after noon and alcohol in the evening, as both can disrupt sleep quality even if they don't prevent you from falling asleep initially.";
  }
  
  // Generic fallback response with guidance
  return "I'll be happy to answer your sleep question. For the most helpful information, try asking about specific topics like sleep duration, quality, positions, health impacts, routines, or foods that affect sleep. You can also ask about issues like insomnia, sleep apnea, or jet lag.";
};

const SleepQA = ({ onQuestionAsked }: SleepQAProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm your sleep assistant. Ask me anything about sleep, insomnia, or healthy sleep habits.",
      type: 'assistant',
      timestamp: new Date()
    }
  ]);
  const [question, setQuestion] = useState("");
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  
  const askQuestion = (text: string) => {
    if (!text.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      type: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setQuestion("");
    
    // Notify parent component if needed
    if (onQuestionAsked) {
      onQuestionAsked(text);
    }
    
    // Simulate assistant thinking
    setTimeout(() => {
      const answer = findAnswer(text);
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: answer,
        type: 'assistant',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    }, 1000);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    askQuestion(question);
  };
  
  // Auto-scroll to the latest message
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);
  
  return (
    <Card className="flex flex-col h-[500px] animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <HelpCircle className="h-5 w-5 text-primary" />
          Sleep Q&A
        </CardTitle>
        <CardDescription>
          Ask questions about sleep and get instant answers
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow overflow-hidden p-0">
        <ScrollArea className="h-full px-4" ref={scrollAreaRef}>
          <div className="space-y-4 pb-4">
            {messages.map((message) => (
              <div 
                key={message.id} 
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`rounded-lg px-4 py-2 max-w-[80%] ${
                    message.type === 'user' 
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted border border-border'
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                  <div className={`text-xs mt-1 ${
                    message.type === 'user' 
                      ? 'text-primary-foreground/70'
                      : 'text-muted-foreground'
                  }`}>
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter className="border-t pt-4">
        <form onSubmit={handleSubmit} className="flex w-full gap-2">
          <div className="relative flex-grow">
            <input
              type="text"
              placeholder="Ask about sleep habits, insomnia, etc."
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
            />
            {!question && (
              <Brain className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            )}
          </div>
          <Button type="submit" size="icon">
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
};

export default SleepQA;
