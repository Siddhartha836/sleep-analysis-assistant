
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { MoonStar, Headphones, Brain, Volume2 } from "lucide-react";

interface WelcomeModalProps {
  onClose: () => void;
  onEnableVoice: () => void;
}

const WelcomeModal = ({ onClose, onEnableVoice }: WelcomeModalProps) => {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Check if user has seen the welcome message before
    const hasSeenWelcome = localStorage.getItem("hasSeenSleepWelcome");
    
    if (!hasSeenWelcome) {
      // Show welcome after a short delay for better UX
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, 800);
      
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    localStorage.setItem("hasSeenSleepWelcome", "true");
    onClose();
  };

  const handleEnableVoice = () => {
    setIsOpen(false);
    localStorage.setItem("hasSeenSleepWelcome", "true");
    onEnableVoice();
  };
  
  // Play welcome sound when modal appears
  useEffect(() => {
    if (isOpen) {
      // Add a small delay to make sure the sound is played after the modal is visible
      const audio = new Audio("https://assets.mixkit.co/sfx/preview/mixkit-magical-sweep-transition-3132.mp3");
      audio.volume = 0.3;
      
      const timer = setTimeout(() => {
        audio.play().catch(err => console.log("Audio prevented:", err));
      }, 300);
      
      return () => {
        clearTimeout(timer);
        audio.pause();
      };
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg animate-scale-in">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto bg-primary/10 p-3 rounded-full mb-3">
            <MoonStar className="h-8 w-8 text-primary" />
          </div>
          <CardTitle className="text-2xl">Welcome to SleepTalk Assistant</CardTitle>
          <CardDescription>Your personal guide to better sleep</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 pt-4">
          <p className="text-center text-muted-foreground">
            SleepTalk helps you track, analyze, and improve your sleep through voice interaction and data visualization.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-6">
            <div className="bg-card border rounded-lg p-3 text-center">
              <Volume2 className="h-5 w-5 mx-auto mb-2 text-primary" />
              <h3 className="font-medium text-sm">Voice Assistant</h3>
              <p className="text-xs text-muted-foreground mt-1">Ask sleep questions using your voice</p>
            </div>
            <div className="bg-card border rounded-lg p-3 text-center">
              <Brain className="h-5 w-5 mx-auto mb-2 text-primary" />
              <h3 className="font-medium text-sm">Smart Analysis</h3>
              <p className="text-xs text-muted-foreground mt-1">Get personalized insights</p>
            </div>
            <div className="bg-card border rounded-lg p-3 text-center">
              <Headphones className="h-5 w-5 mx-auto mb-2 text-primary" />
              <h3 className="font-medium text-sm">Sleep Expert</h3>
              <p className="text-xs text-muted-foreground mt-1">Get evidence-based advice</p>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button 
            onClick={handleEnableVoice}
            className="w-full sm:w-auto"
          >
            <Volume2 className="mr-2 h-4 w-4" />
            Enable Voice Assistant
          </Button>
          <Button 
            variant="outline" 
            onClick={handleClose}
            className="w-full sm:w-auto"
          >
            Continue Without Voice
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default WelcomeModal;
