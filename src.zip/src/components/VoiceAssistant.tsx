
import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Mic, MicOff, Volume2, VolumeX } from "lucide-react";

interface VoiceAssistantProps {
  onQuestionAsked: (question: string) => void;
  isListening: boolean;
  toggleListening: () => void;
}

const VoiceAssistant = ({ onQuestionAsked, isListening, toggleListening }: VoiceAssistantProps) => {
  const [isMuted, setIsMuted] = useState(false);
  const [transcript, setTranscript] = useState("");
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (typeof window !== "undefined" && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      // @ts-ignore - Browser compatibility
      const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognitionAPI();
      
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      
      recognitionRef.current.onresult = (event) => {
        let currentTranscript = "";
        for (let i = 0; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            currentTranscript += event.results[i][0].transcript;
          }
        }
        
        setTranscript(currentTranscript);
        
        // Check if transcript includes a question related to sleep
        const sleepKeywords = ["sleep", "rest", "tired", "insomnia", "dreams", "nap", "bed"];
        const questionIndicators = ["what", "how", "why", "can", "should", "is", "are", "do", "does"];
        
        const words = currentTranscript.toLowerCase().split(" ");
        
        const hasSleepKeyword = words.some(word => sleepKeywords.includes(word));
        const hasQuestionIndicator = words.some(word => questionIndicators.includes(word));
        
        if (hasSleepKeyword && hasQuestionIndicator) {
          onQuestionAsked(currentTranscript);
          setTranscript("");
        }
      };
      
      recognitionRef.current.onerror = (event) => {
        console.error("Speech recognition error", event.error);
      };
    }
    
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [onQuestionAsked]);

  useEffect(() => {
    if (recognitionRef.current) {
      if (isListening) {
        recognitionRef.current.start();
      } else {
        recognitionRef.current.stop();
      }
    }
  }, [isListening]);

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 shadow-md animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-lg">Voice Assistant</h3>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={toggleMute}
            className="transition-all duration-200 hover:bg-primary/20"
          >
            {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </Button>
          <Button 
            variant={isListening ? "default" : "outline"} 
            size="icon" 
            onClick={toggleListening}
            className={`transition-all duration-200 ${isListening ? "bg-primary hover:bg-primary/90" : "hover:bg-primary/20"}`}
          >
            {isListening ? <Mic size={18} className="animate-pulse-gentle" /> : <MicOff size={18} />}
          </Button>
        </div>
      </div>
      
      <div className="bg-muted/60 border border-border rounded-md p-3 min-h-20 max-h-32 overflow-y-auto">
        {transcript ? (
          <p className="text-sm">{transcript}</p>
        ) : (
          <p className="text-sm text-muted-foreground">
            {isListening 
              ? "I'm listening... Ask me about your sleep." 
              : "Press the microphone button to ask questions about sleep."}
          </p>
        )}
      </div>
      
      <div className="mt-3 text-xs text-muted-foreground">
        <p>Try saying: "How can I improve my sleep quality?"</p>
      </div>
    </div>
  );
};

export default VoiceAssistant;
