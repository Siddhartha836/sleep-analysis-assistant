import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

interface AuthGuardProps {
  children: React.ReactNode;
  requireAuth?: boolean;
}

const AuthGuard: React.FC<AuthGuardProps> = ({ children, requireAuth = true }) => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading) {
      if (requireAuth && !user) {
        navigate("/auth");
      } else if (!requireAuth && user) {
        navigate("/");
      }
    }
  }, [user, loading, navigate, requireAuth]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse-slow flex flex-col items-center">
          <div className="w-12 h-12 rounded-full bg-primary/50 mb-4"></div>
          <div className="text-lg text-primary/70">Loading...</div>
        </div>
      </div>
    );
  }

  // If we require auth and have a user, or if we don't require auth and don't have a user, show the children
  if ((requireAuth && user) || (!requireAuth && !user)) {
    return <>{children}</>;
  }

  // Otherwise, return null (the useEffect will handle the redirect)
  return null;
};

export default AuthGuard;
