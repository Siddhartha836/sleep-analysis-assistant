
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Lightbulb, CloudMoon, Timer, Coffee, Smartphone, HeartPulse, ChevronDown } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const SleepTips = () => {
  const [activeTip, setActiveTip] = useState<number | null>(null);

  const tips = [
    {
      icon: <CloudMoon className="h-8 w-8 text-primary mb-2" />,
      title: "Create a Sleep Sanctuary",
      description: "Keep your bedroom dark, quiet, and cool. Use blackout curtains and consider a white noise machine to mask disruptive sounds.",
      details: "Your bedroom environment has a major impact on sleep quality. Aim for a temperature between 60-67°F (15-19°C), and remove electronic devices that emit blue light. Consider using a humidifier if the air is dry, and make sure your mattress and pillows are comfortable and supportive.",
      action: "Try This Tonight"
    },
    {
      icon: <Timer className="h-8 w-8 text-primary mb-2" />,
      title: "Maintain a Schedule",
      description: "Go to bed and wake up at the same time every day, even on weekends, to regulate your body's internal clock.",
      details: "Consistency reinforces your body's sleep-wake cycle. Try to limit the difference in your sleep schedule on weeknights and weekends to no more than one hour. Being consistent reinforces your body's sleep-wake cycle and helps promote better sleep quality.",
      action: "Set Sleep Reminders"
    },
    {
      icon: <Coffee className="h-8 w-8 text-primary mb-2" />,
      title: "Watch Your Consumption",
      description: "Avoid caffeine after 2pm and limit alcohol before bed as it disrupts your sleep cycle and quality.",
      details: "Caffeine can stay in your system for up to 8 hours. Alcohol might help you fall asleep initially, but it prevents deeper, more restorative sleep stages and often leads to waking up in the middle of the night. Nicotine is also a stimulant that can interfere with sleep.",
      action: "Track Consumption"
    },
    {
      icon: <Smartphone className="h-8 w-8 text-primary mb-2" />,
      title: "Digital Sunset",
      description: "Put away electronic devices 1 hour before bed. The blue light from screens interferes with melatonin production.",
      details: "The blue light emitted by your phone, tablet, computer, or TV is especially disruptive. Try reading a physical book, practicing gentle yoga, or meditating instead. If you must use your device, consider wearing blue light blocking glasses or using apps that filter blue/green light.",
      action: "Set Screen Limits"
    },
    {
      icon: <HeartPulse className="h-8 w-8 text-primary mb-2" />,
      title: "Wind Down Routine",
      description: "Practice relaxation techniques like deep breathing, gentle stretching, or reading to signal to your body it's time for sleep.",
      details: "A consistent pre-sleep routine helps transition your body and mind from wake to sleep. Try progressive muscle relaxation, guided meditation, or gentle stretching. A warm bath or shower can also help, as the subsequent drop in body temperature promotes sleepiness.",
      action: "Start Routine"
    }
  ];

  const handleTipAction = (index: number) => {
    setActiveTip(index === activeTip ? null : index);
    toast.success(`${tips[index].title} tip activated!`, {
      description: "We'll remind you about this tip tonight.",
      duration: 3000,
    });
  };

  return (
    <Card className="w-full animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-primary" />
          Sleep Tips
        </CardTitle>
        <CardDescription>
          Evidence-based recommendations for better sleep
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {tips.map((tip, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="mb-4 border rounded-lg overflow-hidden">
              <div className="bg-accent/30 p-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="flex-shrink-0">{tip.icon}</div>
                    <div className="flex-grow">
                      <h3 className="font-medium">{tip.title}</h3>
                      <p className="text-sm text-muted-foreground">{tip.description}</p>
                    </div>
                  </div>
                  <AccordionTrigger className="h-5 w-5 p-0 m-0" />
                </div>
              </div>
              <AccordionContent className="px-4 py-3 bg-background">
                <div className="mb-3">
                  <p className="text-sm">{tip.details}</p>
                </div>
                <Button 
                  size="sm" 
                  onClick={() => handleTipAction(index)}
                  variant={activeTip === index ? "default" : "outline"}
                  className="w-full"
                >
                  {tip.action}
                </Button>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
};

export default SleepTips;
