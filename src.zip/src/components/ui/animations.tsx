
import React, { useEffect, useState } from "react";

interface AnimationWrapperProps {
  className?: string;
  children: React.ReactNode;
  delay?: number;
  duration?: number;
  animation: "fade-in" | "scale-in" | "slide-in";
}

export function AnimationWrapper({
  className,
  children,
  delay = 0,
  duration = 500,
  animation
}: AnimationWrapperProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, delay);

    return () => clearTimeout(timer);
  }, [delay]);

  const getAnimationClass = () => {
    if (!isVisible) return "opacity-0";

    switch (animation) {
      case "fade-in":
        return "animate-fade-in";
      case "scale-in":
        return "animate-scale-in";
      case "slide-in":
        return "animate-slide-in";
      default:
        return "animate-fade-in";
    }
  };

  return (
    <div 
      className={`transition-all ${getAnimationClass()} ${className || ""}`}
      style={{ 
        transitionDuration: `${duration}ms`,
        animationDuration: `${duration}ms`,
      }}
    >
      {children}
    </div>
  );
}
