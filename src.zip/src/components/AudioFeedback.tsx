
import { useEffect, useRef } from "react";

type SoundType = "welcome" | "listening" | "success" | "error" | "notification";

interface AudioFeedbackProps {
  sound: SoundType;
  play: boolean;
  volume?: number;
}

const soundMap: Record<SoundType, string> = {
  welcome: "https://assets.mixkit.co/sfx/preview/mixkit-magical-sweep-transition-3132.mp3",
  listening: "https://assets.mixkit.co/sfx/preview/mixkit-confirmation-tone-2867.mp3",
  success: "https://assets.mixkit.co/sfx/preview/mixkit-tech-notification-success-2293.mp3",
  error: "https://assets.mixkit.co/sfx/preview/mixkit-negative-tone-interface-tap-2569.mp3",
  notification: "https://assets.mixkit.co/sfx/preview/mixkit-software-interface-start-2574.mp3",
};

const AudioFeedback = ({ sound, play, volume = 0.5 }: AudioFeedbackProps) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio(soundMap[sound]);
      audioRef.current.volume = volume;
    } else {
      audioRef.current.src = soundMap[sound];
      audioRef.current.volume = volume;
    }

    if (play) {
      audioRef.current.play().catch(err => {
        // Silent error - often due to user not interacting with page yet
        console.log("Audio playback prevented:", err);
      });
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
    };
  }, [sound, play, volume]);

  return null; // This is a non-visual component
};

export default AudioFeedback;
