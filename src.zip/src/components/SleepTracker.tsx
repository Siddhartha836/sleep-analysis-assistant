
import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Moon, Bed, AlarmClock } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export interface SleepData {
  date: string;
  hoursSlept: number;
  sleepQuality: number;
  notes: string;
}

interface SleepTrackerProps {
  onSleepDataAdded: (data: SleepData) => void;
}

const SleepTracker = ({ onSleepDataAdded }: SleepTrackerProps) => {
  const { toast } = useToast();
  const [hoursSlept, setHoursSlept] = useState<number>(7);
  const [sleepQuality, setSleepQuality] = useState<number>(50);
  const [notes, setNotes] = useState<string>("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const today = new Date().toISOString().split("T")[0];
    
    const sleepData: SleepData = {
      date: today,
      hoursSlept,
      sleepQuality,
      notes
    };
    
    onSleepDataAdded(sleepData);
    
    // Reset form
    setHoursSlept(7);
    setSleepQuality(50);
    setNotes("");
    
    toast({
      title: "Sleep log added",
      description: "Your sleep data has been saved successfully.",
    });
  };
  
  return (
    <Card className="w-full animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Moon className="h-5 w-5 text-primary" />
          Track Your Sleep
        </CardTitle>
        <CardDescription>
          Log your sleep details to track patterns and improve sleep quality
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit}>
          <div className="grid w-full gap-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="hours">Hours Slept</Label>
                <span className="text-sm font-medium">{hoursSlept} hours</span>
              </div>
              <div className="flex items-center gap-3">
                <Bed className="h-4 w-4 text-muted-foreground" />
                <Slider 
                  id="hours"
                  min={0} 
                  max={12} 
                  step={0.5}
                  value={[hoursSlept]}
                  onValueChange={(value) => setHoursSlept(value[0])}
                  className="flex-1"
                />
                <AlarmClock className="h-4 w-4 text-muted-foreground" />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="quality">Sleep Quality</Label>
                <span className="text-sm font-medium">{sleepQuality}%</span>
              </div>
              <Slider 
                id="quality"
                min={0} 
                max={100} 
                step={1}
                value={[sleepQuality]}
                onValueChange={(value) => setSleepQuality(value[0])}
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Poor</span>
                <span>Excellent</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Input
                id="notes"
                placeholder="Any notes about your sleep? (e.g., dreams, interruptions)"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>
          </div>
          
          <Button type="submit" className="w-full mt-4">
            Save Sleep Data
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default SleepTracker;
