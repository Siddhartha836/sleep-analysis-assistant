
import { useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SleepData } from "./SleepTracker";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Moon, TrendingUp, Zap } from "lucide-react";

interface SleepAnalysisProps {
  sleepData: SleepData[];
}

const SleepAnalysis = ({ sleepData }: SleepAnalysisProps) => {
  const averageHours = useMemo(() => {
    if (sleepData.length === 0) return 0;
    const sum = sleepData.reduce((acc, data) => acc + data.hoursSlept, 0);
    return (sum / sleepData.length).toFixed(1);
  }, [sleepData]);
  
  const averageQuality = useMemo(() => {
    if (sleepData.length === 0) return 0;
    const sum = sleepData.reduce((acc, data) => acc + data.sleepQuality, 0);
    return Math.round(sum / sleepData.length);
  }, [sleepData]);
  
  const getSleepTrend = () => {
    if (sleepData.length < 3) {
      return { status: "neutral", message: "Not enough data" };
    }
    
    const recentData = sleepData.slice(-3);
    const qualityTrend = recentData[2].sleepQuality - recentData[0].sleepQuality;
    const hoursTrend = recentData[2].hoursSlept - recentData[0].hoursSlept;
    
    if (qualityTrend > 5 && hoursTrend > 0.5) {
      return { status: "improving", message: "Your sleep is improving!" };
    } else if (qualityTrend < -5 && hoursTrend < -0.5) {
      return { status: "declining", message: "Your sleep quality is declining" };
    } else {
      return { status: "stable", message: "Your sleep pattern is stable" };
    }
  };
  
  const sleepTrend = getSleepTrend();
  
  const chartData = sleepData.map((data) => ({
    date: data.date,
    hours: data.hoursSlept,
    quality: data.sleepQuality,
  }));
  
  const getSleepInsight = () => {
    if (sleepData.length === 0) {
      return "Start tracking your sleep to get personalized insights.";
    }
    
    const lastEntry = sleepData[sleepData.length - 1];
    
    if (lastEntry.hoursSlept < 6) {
      return "You're not getting enough sleep. Aim for 7-9 hours for optimal health.";
    } else if (lastEntry.sleepQuality < 40) {
      return "Your sleep quality is low. Try to create a more comfortable sleep environment.";
    } else if (lastEntry.hoursSlept > 9) {
      return "You might be oversleeping. This can sometimes lead to feeling groggy.";
    } else if (lastEntry.sleepQuality > 75 && lastEntry.hoursSlept >= 7) {
      return "Great job! You're getting quality sleep that will help your body recover.";
    } else {
      return "Your sleep pattern is within normal ranges. Keep maintaining regular sleep habits.";
    }
  };
  
  return (
    <Card className="w-full animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          Sleep Analysis
        </CardTitle>
        <CardDescription>
          Visualize your sleep patterns and get personalized insights
        </CardDescription>
      </CardHeader>
      <CardContent>
        {sleepData.length === 0 ? (
          <div className="text-center p-6 border border-dashed rounded-md">
            <Moon className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
            <h3 className="font-medium mb-1">No sleep data yet</h3>
            <p className="text-sm text-muted-foreground">
              Start tracking your sleep to view analysis
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-card p-3 rounded-lg border text-center">
                <div className="text-muted-foreground text-xs mb-1">Avg Hours</div>
                <div className="text-2xl font-bold">{averageHours}</div>
              </div>
              <div className="bg-card p-3 rounded-lg border text-center">
                <div className="text-muted-foreground text-xs mb-1">Quality</div>
                <div className="text-2xl font-bold">{averageQuality}%</div>
              </div>
              <div className="bg-card p-3 rounded-lg border text-center">
                <div className="text-muted-foreground text-xs mb-1">Trend</div>
                <Badge variant={
                  sleepTrend.status === "improving" ? "default" : 
                  sleepTrend.status === "declining" ? "destructive" : "secondary"
                } className="mt-1">
                  {sleepTrend.status}
                </Badge>
              </div>
            </div>
            
            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                  <YAxis yAxisId="left" orientation="left" domain={[0, 12]} tick={{ fontSize: 12 }} />
                  <YAxis yAxisId="right" orientation="right" domain={[0, 100]} tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Legend />
                  <Line
                    yAxisId="left"
                    type="monotone"
                    dataKey="hours"
                    name="Hours Slept"
                    stroke="#8884d8"
                    strokeWidth={2}
                    dot={{ r: 3 }}
                    activeDot={{ r: 5 }}
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="quality"
                    name="Sleep Quality"
                    stroke="#82ca9d"
                    strokeWidth={2}
                    dot={{ r: 3 }}
                    activeDot={{ r: 5 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            
            <div className="bg-accent/50 p-4 rounded-lg flex gap-3">
              <Zap className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium mb-1 text-sm">Sleep Insight</h4>
                <p className="text-sm text-muted-foreground">{getSleepInsight()}</p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SleepAnalysis;
