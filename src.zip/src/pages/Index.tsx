import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { MoonStar, Volume2, BadgeHelp, Lightbulb } from "lucide-react";
import VoiceAssistant from "@/components/VoiceAssistant";
import SleepTracker, { SleepData } from "@/components/SleepTracker";
import SleepAnalysis from "@/components/SleepAnalysis";
import SleepQA from "@/components/SleepQA";
import SleepTips from "@/components/SleepTips";
import WelcomeModal from "@/components/WelcomeModal";
import AudioFeedback from "@/components/AudioFeedback";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import UserMenu from "@/components/UserMenu";

type SoundType = "welcome" | "listening" | "success" | "error" | "notification";

const Index = () => {
  const [sleepData, setSleepData] = useState<SleepData[]>(() => {
    const saved = localStorage.getItem('sleepData');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [isListening, setIsListening] = useState(false);
  const [activeTab, setActiveTab] = useState("track");
  const [soundToPlay, setSoundToPlay] = useState<{type: SoundType, play: boolean}>({
    type: "welcome", 
    play: false
  });
  const { toast } = useToast();
  
  useEffect(() => {
    localStorage.setItem('sleepData', JSON.stringify(sleepData));
  }, [sleepData]);
  
  const handleSleepDataAdded = (data: SleepData) => {
    setSleepData(prev => [...prev, data]);
    setSoundToPlay({type: "success", play: true});
    setTimeout(() => setSoundToPlay({type: "success", play: false}), 1000);
  };
  
  const handleQuestionAsked = (question: string) => {
    toast({
      title: "Question Received",
      description: `"${question.substring(0, 50)}${question.length > 50 ? '...' : ''}"`,
      duration: 3000,
    });
    
    setSoundToPlay({type: "notification", play: true});
    setTimeout(() => setSoundToPlay({type: "notification", play: false}), 1000);
    
    setActiveTab("qa");
  };
  
  const toggleListening = () => {
    setIsListening(prev => !prev);
    
    if (!isListening) {
      toast({
        title: "Voice Assistant Activated",
        description: "I'm listening for your sleep questions...",
      });
      setSoundToPlay({type: "listening", play: true});
      setTimeout(() => setSoundToPlay({type: "listening", play: false}), 1000);
    }
  };
  
  const handleCloseWelcome = () => {
  };
  
  const handleEnableVoice = () => {
    setIsListening(true);
    toast({
      title: "Voice Assistant Enabled",
      description: "Ask me any questions about sleep!",
    });
    setSoundToPlay({type: "listening", play: true});
    setTimeout(() => setSoundToPlay({type: "listening", play: false}), 1000);
  };
  
  return (
    <div className="min-h-screen bg-background dark:night-sky starry-bg">
      <AudioFeedback 
        sound={soundToPlay.type} 
        play={soundToPlay.play} 
        volume={0.3} 
      />
      <WelcomeModal onClose={handleCloseWelcome} onEnableVoice={handleEnableVoice} />
      <header className="border-b">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center gap-2">
            <MoonStar className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-semibold">SleepTalk Assistant</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={toggleListening}>
              <Volume2 className="h-4 w-4 mr-2" />
              {isListening ? "Stop Listening" : "Start Voice Assistant"}
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setActiveTab("qa")}>
              <BadgeHelp className="h-5 w-5" />
            </Button>
            <ThemeToggle />
            <UserMenu />
          </div>
        </div>
      </header>
      
      <main className="container px-4 py-8">
        <div className="mb-8">
          <VoiceAssistant 
            onQuestionAsked={handleQuestionAsked} 
            isListening={isListening}
            toggleListening={toggleListening}
          />
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="track">Track Sleep</TabsTrigger>
            <TabsTrigger value="analyze">Analyze</TabsTrigger>
            <TabsTrigger value="qa">Ask Questions</TabsTrigger>
            <TabsTrigger value="tips">Sleep Tips</TabsTrigger>
          </TabsList>
          
          <TabsContent value="track" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-8">
              <SleepTracker onSleepDataAdded={handleSleepDataAdded} />
              <div className="bg-card border rounded-lg p-6 flex flex-col items-center justify-center sleep-gradient animate-pulse-gentle">
                <MoonStar className="h-16 w-16 text-primary mb-4" />
                <h2 className="text-2xl font-bold mb-2">Better Sleep Awaits</h2>
                <p className="text-center text-muted-foreground mb-4">
                  Track your sleep patterns and get personalized insights to improve your rest
                </p>
                <Button 
                  variant="default" 
                  className="mt-2"
                  onClick={() => setActiveTab("analyze")}
                >
                  View Your Sleep Analysis
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="analyze">
            <SleepAnalysis sleepData={sleepData} />
          </TabsContent>
          
          <TabsContent value="qa">
            <SleepQA onQuestionAsked={handleQuestionAsked} />
          </TabsContent>
          
          <TabsContent value="tips">
            <SleepTips />
          </TabsContent>
        </Tabs>
      </main>
      
      <footer className="border-t py-6 mt-8">
        <div className="container px-4 text-center">
          <p className="text-sm text-muted-foreground">
            SleepTalk Assistant - Your guide to better sleep habits and quality rest
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
